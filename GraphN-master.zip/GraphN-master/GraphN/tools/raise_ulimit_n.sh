sudo sh -c "ulimit -n 1048576 && exec su $LOGNAME"
